PROTEUS_WEAPONSELECTOR = PROTEUS_WEAPONSELECTOR or {}
PROTEUS_WEAPONSELECTOR.Version = "2.0.0"
PROTEUS_WEAPONSELECTOR.Name = "Proteus Weapon Selector"

local root = "proteus_weaponselector/"
local shared = {
	"sh_config.lua",
	"sh_util.lua"
}
local client = {
	"cl_selector.lua"
}

for _, fileName in ipairs(shared) do
	if SERVER then
		AddCSLuaFile(root .. fileName)
	end

	include(root .. fileName)
end

if SERVER then
	for _, fileName in ipairs(client) do
		AddCSLuaFile(root .. fileName)
	end
else
	for _, fileName in ipairs(client) do
		include(root .. fileName)
	end
end
