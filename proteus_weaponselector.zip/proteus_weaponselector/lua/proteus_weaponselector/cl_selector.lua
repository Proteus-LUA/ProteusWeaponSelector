PROTEUS_WEAPONSELECTOR = PROTEUS_WEAPONSELECTOR or {}

local selector = {}
selector.index = 1
selector.deltaIndex = 1
selector.alpha = 0
selector.alphaDelta = 0
selector.infoAlpha = 0
selector.fadeTime = 0
selector.weapons = {}
selector.markup = nil

local matrixScale = Vector(1, 1, 0)

local function Config(key, fallback)
	return PROTEUS_WEAPONSELECTOR.GetConfig(key, fallback)
end

local function AlphaColor(color, alpha)
	return Color(color.r, color.g, color.b, math.Clamp(alpha, 0, 255))
end

local function Upper(text)
	text = tostring(text or "")

	if string.utf8upper then
		return string.utf8upper(text)
	end

	return string.upper(text)
end

local function CreateFonts()
	surface.CreateFont("ProteusWS_HelixName", {
		font = Config("Font", "Roboto"),
		size = ScreenScale(Config("FontSize", 16)),
		extended = true,
		weight = Config("FontWeight", 1000),
		antialias = true
	})

	surface.CreateFont("ProteusWS_HelixInfo", {
		font = Config("Font", "Roboto"),
		size = ScreenScale(Config("InfoFontSize", 8)),
		extended = true,
		weight = 500,
		antialias = true
	})

	surface.CreateFont("ProteusWS_HelixInfoTitle", {
		font = Config("Font", "Roboto"),
		size = ScreenScale(Config("InfoTitleSize", 9)),
		extended = true,
		weight = 900,
		antialias = true
	})
end

CreateFonts()
hook.Add("OnScreenSizeChanged", "ProteusWeaponSelector.Fonts", CreateFonts)

local function GetWeapons(client)
	local list = {}

	if not IsValid(client) then
		return list
	end

	for _, weapon in ipairs(client:GetWeapons()) do
		if PROTEUS_WEAPONSELECTOR.IsWeaponAllowed(weapon) then
			table.insert(list, weapon)
		end
	end

	if Config("SortBySlot", false) then
		table.sort(list, PROTEUS_WEAPONSELECTOR.SortWeapons)
	end

	return list
end

local function CanUseSelector(client)
	if not Config("Enabled", true) then
		return false
	end

	if not IsValid(client) or not client:Alive() then
		return false
	end

	if Config("BlockInVehicle", true) and client:InVehicle() then
		return false
	end

	if Config("BlockWhenTyping", true) and gui.IsGameUIVisible() then
		return false
	end

	if Config("BlockWhenTyping", true) and IsValid(vgui.GetKeyboardFocus()) then
		return false
	end

	return true
end

local function RefreshWeapons(client)
	selector.weapons = GetWeapons(client)

	if #selector.weapons <= 0 then
		selector.index = 1
		selector.deltaIndex = 1
		return
	end

	selector.index = math.Clamp(selector.index, 1, #selector.weapons)
	selector.deltaIndex = math.Clamp(selector.deltaIndex, 1, #selector.weapons)
end

local function DrawText(text, font, x, y, color, alignX, alignY)
	draw.SimpleText(text, font, x + 1, y + 1, Color(0, 0, 0, color.a * 0.55), alignX, alignY)
	draw.SimpleText(text, font, x, y, color, alignX, alignY)
end

local function TrimText(font, text, maxWidth)
	text = tostring(text or "")
	surface.SetFont(font)

	local width = surface.GetTextSize(text)

	if width <= maxWidth then
		return text
	end

	local result = text

	while #result > 0 do
		local test = result .. "..."
		local testWidth = surface.GetTextSize(test)

		if testWidth <= maxWidth then
			return test
		end

		result = string.sub(result, 1, #result - 1)
	end

	return "..."
end

local function GetWeaponAmmoText(client, weapon)
	if not Config("ShowAmmo", true) or not IsValid(client) or not IsValid(weapon) then
		return ""
	end

	local clip = weapon:Clip1()
	local ammoType = weapon:GetPrimaryAmmoType()
	local reserve = ammoType and ammoType >= 0 and client:GetAmmoCount(ammoType) or 0

	if clip and clip >= 0 then
		return clip .. " / " .. reserve
	end

	if reserve and reserve > 0 then
		return tostring(reserve)
	end

	return ""
end

local function BuildInfo(weapon)
	selector.markup = nil
	selector.infoAlpha = 0

	if not Config("ShowInstructions", true) or not IsValid(weapon) then
		return
	end

	local instructions = weapon.Instructions

	if not instructions or not tostring(instructions):find("%S") then
		return
	end

	local primary = Config("PrimaryColor", Color(42, 139, 255))
	local text = string.format("<font=ProteusWS_HelixInfoTitle><color=255,255,255>INSTRUCTIONS</color></font>\n<font=ProteusWS_HelixInfo><color=255,255,255>%s</color></font>", tostring(instructions))
	selector.markup = markup.Parse(text, ScrW() * 0.3)
end

local function OnIndexChanged(weapon)
	selector.alpha = 1
	selector.fadeTime = CurTime() + Config("CloseDelay", 5)
	BuildInfo(weapon)

	if Config("UseCycleSound", true) and IsValid(LocalPlayer()) then
		LocalPlayer():EmitSound(Config("CycleSound", "common/talk.wav"), Config("CycleSoundVolume", 50), Config("CycleSoundPitch", 180))
	end
end

local function SelectWeapon(client)
	local weapon = selector.weapons[selector.index]

	if not IsValid(weapon) then
		return
	end

	if Config("UseSelectSound", true) then
		client:EmitSound(Config("SelectSound", "HL2Player.Use"))
	end

	input.SelectWeapon(weapon)
	selector.alpha = 0
end

hook.Add("HUDShouldDraw", "ProteusWeaponSelector.HideDefault", function(name)
	if Config("HideDefaultSelector", true) and name == "CHudWeaponSelection" then
		return false
	end
end)

hook.Add("HUDPaint", "ProteusWeaponSelector.Draw", function()
	local frameTime = FrameTime()
	selector.alphaDelta = Lerp(frameTime * Config("AnimationSpeed", 10), selector.alphaDelta, selector.alpha)

	local fraction = selector.alphaDelta

	if fraction <= 0.01 then
		return
	end

	local client = LocalPlayer()
	RefreshWeapons(client)

	if #selector.weapons <= 0 then
		selector.alpha = 0
		return
	end

	if not selector.weapons[selector.index] then
		selector.index = #selector.weapons
	end

	local x = ScrW() * 0.5
	local y = ScrH() * 0.5
	local spacing = math.pi * Config("Spacing", 0.85)
	local radius = Config("Radius", 240) * selector.alphaDelta
	local shiftX = ScrW() * Config("ShiftX", 0.02)
	local primary = Config("PrimaryColor", Color(42, 139, 255))
	local textColor = Config("TextColor", Color(255, 255, 255))
	local infoColor = Config("InfoColor", Color(255, 255, 255))
	local mutedColor = Config("InfoMutedColor", Color(255, 255, 255))

	selector.deltaIndex = Lerp(frameTime * Config("IndexSpeed", 12), selector.deltaIndex, selector.index)

	for i = 1, #selector.weapons do
		local weapon = selector.weapons[i]
		local theta = (i - selector.deltaIndex) * 0.1
		local alpha = (255 - math.abs(theta * 3) * 255) * fraction
		local color = textColor
		local weaponName = Upper(language.GetPhrase(PROTEUS_WEAPONSELECTOR.GetWeaponName(weapon)))
		local _, ty = surface.GetTextSize(weaponName)
		local scale = math.max(0.05, 1 - math.abs(theta * 2))
		local lastY = 0

		if selector.markup and (i < selector.index or i == 1) then
			if selector.index ~= 1 then
				local _, h = selector.markup:Size()
				lastY = h * fraction
			end

			if i == 1 or i == selector.index - 1 then
				selector.infoAlpha = Lerp(frameTime * Config("InfoSpeed", 3), selector.infoAlpha, 255)
				selector.markup:Draw(x + 6 + shiftX, y + 30, 0, 0, selector.infoAlpha * fraction)
			end
		end

		surface.SetFont("ProteusWS_HelixName")
		weaponName = TrimText("ProteusWS_HelixName", weaponName, ScrW() * 0.35)
		_, ty = surface.GetTextSize(weaponName)

		local matrix = Matrix()
		matrix:Translate(Vector(shiftX + x + math.cos(theta * spacing + math.pi) * radius + radius, y + lastY + math.sin(theta * spacing + math.pi) * radius - ty / 2, 1))
		matrix:Scale(matrixScale * scale)

		cam.PushModelMatrix(matrix)
			DrawText(weaponName, "ProteusWS_HelixName", 2, ty / 2, AlphaColor(color, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		cam.PopModelMatrix()
	end

	local weapon = selector.weapons[selector.index]
	local ammoText = GetWeaponAmmoText(client, weapon)
	local classText = IsValid(weapon) and weapon:GetClass() or ""
	local bottomY = ScrH() * 0.5 + 76


	if ammoText ~= "" then
		DrawText(ammoText, "ProteusWS_HelixInfo", x + shiftX + 6, bottomY, AlphaColor(mutedColor, 170 * fraction), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	elseif Config("ShowClass", false) and classText ~= "" then
		DrawText(classText, "ProteusWS_HelixInfo", x + shiftX + 6, bottomY, AlphaColor(mutedColor, 170 * fraction), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	if selector.fadeTime < CurTime() and selector.alpha > 0 then
		selector.alpha = 0
	end
end)

hook.Add("PlayerBindPress", "ProteusWeaponSelector.BindPress", function(client, bind, pressed)
	bind = string.lower(bind or "")

	if not pressed then
		return
	end

	if not bind:find("invprev", 1, true) and not bind:find("invnext", 1, true) and not bind:find("slot") and not bind:find("attack", 1, true) and not bind:find("cancelselect", 1, true) then
		return
	end

	if not CanUseSelector(client) then
		return
	end

	local currentWeapon = client:GetActiveWeapon()
	local currentValid = IsValid(currentWeapon)

	if Config("BlockPhysgunAttack", true) and currentValid and currentWeapon:GetClass() == "weapon_physgun" and client:KeyDown(IN_ATTACK) then
		return
	end

	local toolScroll = false

	if currentValid and currentWeapon:GetClass() == "gmod_tool" and client.GetTool then
		local tool = client:GetTool()
		toolScroll = tool and tool.Scroll ~= nil
	end

	RefreshWeapons(client)

	if #selector.weapons <= 0 then
		return
	end

	if bind:find("invprev", 1, true) and not toolScroll then
		local oldIndex = selector.index
		selector.index = math.min(selector.index + 1, #selector.weapons)

		if selector.alpha == 0 or oldIndex ~= selector.index then
			OnIndexChanged(selector.weapons[selector.index])
		end

		return true
	end

	if bind:find("invnext", 1, true) and not toolScroll then
		local oldIndex = selector.index
		selector.index = math.max(selector.index - 1, 1)

		if selector.alpha == 0 or oldIndex ~= selector.index then
			OnIndexChanged(selector.weapons[selector.index])
		end

		return true
	end

	if bind:find("slot") then
		selector.index = math.Clamp(tonumber(bind:match("slot(%d)")) or 1, 1, #selector.weapons)
		OnIndexChanged(selector.weapons[selector.index])
		return true
	end

	if bind:find("attack", 1, true) and selector.alpha > 0 then
		SelectWeapon(client)
		return true
	end

	if bind:find("cancelselect", 1, true) and selector.alpha > 0 then
		selector.alpha = 0
		return true
	end
end)

hook.Add("Think", "ProteusWeaponSelector.State", function()
	local client = LocalPlayer()

	if not IsValid(client) or not client:Alive() then
		selector.alpha = 0
	end
end)

hook.Add("ScoreboardShow", "ProteusWeaponSelector.CloseScoreboard", function()
	selector.alpha = 0
end)
