PROTEUS_WEAPONSELECTOR = PROTEUS_WEAPONSELECTOR or {}

local Config = {}

Config.Enabled = true
Config.HideDefaultSelector = true
Config.CloseDelay = 5
Config.AnimationSpeed = 10
Config.IndexSpeed = 12
Config.InfoSpeed = 3
Config.Radius = 240
Config.Spacing = 0.85
Config.ShiftX = 0.02
Config.Font = "Roboto"
Config.FontSize = 16
Config.FontWeight = 1000
Config.InfoFontSize = 8
Config.InfoTitleSize = 9
Config.PrimaryColor = Color(255, 255, 255)
Config.TextColor = Color(255, 255, 255)
Config.InfoColor = Color(255, 255, 255)
Config.InfoMutedColor = Color(255, 255, 255)
Config.InfoBackgroundColor = Color(8, 8, 12)
Config.ShowInstructions = true
Config.ShowAmmo = true
Config.ShowClass = false
Config.ShowCounter = false
Config.SortBySlot = false
Config.BlockInVehicle = true
Config.BlockWhenTyping = true
Config.BlockPhysgunAttack = true
Config.UseCycleSound = true
Config.UseSelectSound = true
Config.CycleSound = "common/talk.wav"
Config.CycleSoundVolume = 50
Config.CycleSoundPitch = 180
Config.SelectSound = "HL2Player.Use"
Config.DisabledWeapons = {
	["gmod_camera"] = false,
	["weapon_physgun"] = false,
	["gmod_tool"] = false
}

PROTEUS_WEAPONSELECTOR.Config = Config
