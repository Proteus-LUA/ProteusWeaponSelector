PROTEUS_WEAPONSELECTOR = PROTEUS_WEAPONSELECTOR or {}

function PROTEUS_WEAPONSELECTOR.GetConfig(key, fallback)
	local config = PROTEUS_WEAPONSELECTOR.Config or {}
	local value = config[key]

	if value == nil then
		return fallback
	end

	return value
end

function PROTEUS_WEAPONSELECTOR.IsWeaponAllowed(weapon)
	if not IsValid(weapon) then
		return false
	end

	local disabled = PROTEUS_WEAPONSELECTOR.GetConfig("DisabledWeapons", {})
	local class = weapon:GetClass()

	if disabled[class] == true then
		return false
	end

	return true
end

function PROTEUS_WEAPONSELECTOR.GetWeaponName(weapon)
	if not IsValid(weapon) then
		return "INCONNU"
	end

	local printName = weapon:GetPrintName()

	if printName and printName ~= "" then
		return language.GetPhrase(printName)
	end

	return weapon:GetClass()
end

function PROTEUS_WEAPONSELECTOR.SortWeapons(a, b)
	local slotA = a:GetSlot() or 0
	local slotB = b:GetSlot() or 0

	if slotA == slotB then
		return (a:GetSlotPos() or 0) < (b:GetSlotPos() or 0)
	end

	return slotA < slotB
end
